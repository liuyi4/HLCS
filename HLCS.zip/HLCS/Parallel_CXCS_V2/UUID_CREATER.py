import uuid
class UUID_GENERATER:
    def __init__(self):
        self.UUID=str(uuid.uuid4())
        self.save_uuid()

    
    def save_performance(self,txt,name):
        f=open(name,'wb')
        f.write(txt)
        f.close()

    def save_uuid(self):
        self.save_performance(self.UUID,'uuid.txt')

U=UUID_GENERATER()