﻿class OIS_Global_Config:
    def __init__(self):
        ################## configs for environment machine ############
        #The problem types
        #self.Question_Types=['multiplexer','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'dv1']
        self.Question_Types=['multiplexer','carry', 'evenParity', 'majorityOn']
        #The the most outer floder to solve the environment
        self.environment_dictionary='Test_Environment'
        #The file type, which save the environments
        self.File_Environmet_Basic_Type=".txt"

        self.condition_length=11   #  the length of the condition

        self.posBits = 3 # for multiplexer problem 11bit posbit=3, 6 bit posbit=2

        self.numRelevantBits = 2# for hidden problems

        self.posRelevantBits = [0,1] # for hidden problems

        self.config_Vs=['8f225d79_10fa_4828_857f_e6f795d1f7c8','b038cadd_2b6f_4f09_9bd5_db8594b5ccb5','6673fb49_864c_4ff5_a1ee_5d40a1802895']

        self.XCS_V=['45598a9f_15e3_4393_b4e4_da00bc199dfd']

        

        ####################config settings ########################
        self.config_saveplace='config'

        self.config_save_type='.txt'

        ####################XCS Agent settings ########################
        self.xcs_saveplace='Agent'

        self.XCS_save_type='.txt'

        self.XCS_Name='XCS_'

        self.XCS_AgentName='Agent_'

        self.XCS_config_Name='Config_'

        self.XCS_Problem_Name='Problem_'

        self.XCS_Problem_Length_Name='Plength_'

        self.XCS_Finish_Time_Name='FTime_'

        ####################Required system settings ########################
        self.Required_default_Questions=[0,1,2,3,4,5,6]

        self.multiplexer_posbits=[1,2,3,4,5,6,7,8,9,10,11]

        self.multiplexer_length=[3,6,11,20,37,70,135,264,521,1034,2059]

        ####################Knowledge settings ##############################
        self.Knowledge_saveplace='Knowledge'

        self.Knowledge_savetype='.txt'

        self.Knowledge_Document_Name='knowledge'

        ####################Percept settings ##############################
        self.Percept_saveplace='Percept'

        self.Percept_savetype='.txt'

        self.Percept_Document_Name='Percept'

        ###############Accuracy results##########################
        self.Accuracy_saveplace='Accuracy_result'

        self.Accuracy_savetype='.txt'

        ###############Test Names for Gravitation ###########################

        self.Gravitation_test_name=['6_multiplexer_0001','6_carry_0001','6_evenparity_0001','6_majorityon_0001','6_evenparity_0002']

        self.Gravitation_savetype='.txt'

        self.Gravitation_correct='_Correct'

        self.Gravitation_Icorrect='_ICorrect'

        self.Gravitation_save_fold='Gravitation_Test'

        self.Gravitation_indicate_symbol='========> '

        self.Gravitation_empty_space=' '

        self.Gravitation_numerousity=' Number '

        ###################### opposite search Accuracy result #################
        self.opposite_search_accuracy_save_fold='opposite_search_accuracy'

        self.opposite_search_accuracy__savetype='.txt'


        ###################### classifier rules number distribution #################
        self.rule_number_folder='rule_number'
        self.rule_number_savetype='.txt'