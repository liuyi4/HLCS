﻿import random
import math
from Config import standard_XCS_config
import csv
import copy
class environment:
    def __init__(self):
        self.multiplexer_posbits=[1,2,3,4,5,6,7,8,9,10,11]
        self.multiplexer_length=[3,6,11,20,37,70,135,264,521,1034,2059]
        config=standard_XCS_config()
        self.maxPayOff=config.maxPayOff

     #Create a state
    def Create_Set_condition(self,length):
        state=[0]*length
        for i in range(0, length):
            random_number=random.randint(0,1)
            if(random_number==0):
                state[i]=0
            else:
                state[i]=1
        return state

    # generate multiplexer result
    def execute_Multiplexer_Action(self,state):
        actual_Action=0
        length=len(state)
        post_Bits=1
        for number in range(0,len(self.multiplexer_length)):
            if length==self.multiplexer_length[number]:
                post_Bits=self.multiplexer_posbits[number]
        place=post_Bits
        for i in range(0,post_Bits):
            if state[i]==1:
                place=place+int(math.pow(2.0,float(post_Bits-1-i)))
                #print place
        if state[place]==1:
            actual_Action=1
        return actual_Action

    # generate carry result
    def execute_Carry_Action(self,state):
        carry=0
        actual_Action=0
        half_condition=len(state)/2
        for i in range(0, half_condition):
            carry=(carry+int(state[half_condition-1-i])+int(state[half_condition-1-i+half_condition]))/2
        if carry==1:
            actual_Action=1
        return actual_Action

    # generate even parity result
    def execute_Even_parity_Action(self,state):
        numbers=0
        actual_Action=0
        for i in range(0,len(state)):
            if state[i]==1:
                numbers=numbers+1
        if numbers%2==0:
            actual_Action=1
        return actual_Action

    # generate the majority on result
    def execute_Majority_On_Action(self,state):
        actual_Action=0
        Numbers=0
        for i in range(0,len(state)):
            if(state[i]==1):
                Numbers=Numbers+1
        if Numbers>(len(state)/2):
            actual_Action=1
        return actual_Action

    # This function is for reinforcement learning     
    def executeAction(self, exenumber,state,action):
        ret=0
        #['multiplexer','carry', 'evenParity', 'majorityOn']
        if exenumber==0:
            #result=self.execute_Multiplexer_Action(state)
            result=self.execute_Multiplexer_Action(state)
        elif exenumber==1:
            #result=self.execute_Carry_Action(state)
            result=self.execute_Carry_Action(state)
        elif exenumber==2:
            result=self.execute_Even_parity_Action(state)
        elif exenumber==3:
            #result=self.execute_Majority_On_Action(state)
            result=self.execute_Majority_On_Action(state)

        if result==action:
            ret=self.maxPayOff
        return ret

class R_environment:
    def __init__(self,problem_type,id):
        #rewqrd
        self.maxPayOff=1000
        #number of actions
        self.actions=None
        #number of attributes
        self.attributes=None
        self.problem_types=['IrisG','WineG','Australian','Zoo','German','Ionosphere','Sonar','abalone','WBCD','Lung_Cancer','Hill_Vally_without_noise'
                            ,'IrisF','IrisS','IrisT','WineF','WineS','WineT','SpliceG','SpliceF','SpliceS','SpliceT','WaveG','WaveF','WaveS','WaveT'
                            ,'Australia_1','German_1','Lung_Cancer_1','Hill_Vally_without_noise_1']
        self.problem_type=self.problem_types[problem_type]
        self.state=[]
        self.produced_actions=[]
        self.Whole_state=[]
        self.Whole_action=[]
        self.read_environment(self.problem_type)
        self.length=len(self.state)
        self.round_set_size=self.calculate_float_size()
       
        #self.Build_Training_Data_set(id)

        self.low,self.up=self.get_limitation()
        #print (self.low,self.up)

    def get_limitation(self):
        up=[]
        low=[]
        for i in range(0,len(self.state[0])):
            up.append(-5000)
            low.append(5000)
        for i in range(0,len(self.produced_actions)):
            for j in range(0,len(self.state[0])):
                if low[j]>self.state[i][j]:
                    low[j]=self.state[i][j]
                if up[j]<self.state[i][j]:
                    up[j]=self.state[i][j]
        #print low,up
        return low,up

    def Read_CSV(self,path):
        with open(path) as f:
            f_csv=csv.reader(f)
            headers=next(f_csv)
            results=[]
            for row in f_csv:
                results.append(row)
            return results

    def global_IRIS(self):
        attribute=4
        
        IRIS=self.Read_CSV('R_env\\iris_id.csv')
        datas=[]
        actions=[]
        for i in range(0,len(IRIS)):
            data=[]
            for j in range(0,attribute):
                data.append(float(IRIS[i][j]))
            datas.append(data)
            if IRIS[i][attribute]=='1':
                actions.append(0)
            elif IRIS[i][attribute]=='2':
                actions.append(1)
            elif IRIS[i][attribute]=='3':
                actions.append(2)
        #print actions
        #print datas
        return actions,datas

    def read_environment(self,type):
        if type=='IrisG':
            actions,datas=self.global_IRIS()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=3
            self.attributes=4
        elif type=='WineG':
            actions,datas=self.global_wine()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=3
            self.attributes=13
        elif type=='Australian':
            actions,datas=self.global_Australian()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=14
        elif type=='Zoo':
            actions,datas=self.global_Zoo()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=7
            self.attributes=16
        elif type=='German':
            actions,datas=self.global_German()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=24
        elif type=='Ionosphere':
            actions,datas=self.global_Ionosphere()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=34
        elif type=='Sonar':
            actions,datas=self.global_Sonar()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=60
        elif type=='abalone':
            actions,datas=self.global_abalone()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=29
            self.attributes=8
        elif type=='WBCD':
            actions,datas=self.global_WBCD()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=9
        elif type=='Lung_Cancer':
            actions,datas=self.global_Lung_Cancer()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=56
        elif type=='Hill_Vally_without_noise':
            actions,datas=self.global_Lung_Hill_vally_without_noise()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=100
        elif type=='IrisF':
            actions,datas=self.First_IRIS()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=4
        elif type=='IrisS':
            actions,datas=self.Second_IRIS()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=4
        elif type=='IrisT':
            actions,datas=self.Third_IRIS()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=4
        elif type=='WineF':
            actions,datas=self.First_Wine()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=13
        elif type=='WineS':
            actions,datas=self.Second_Wine()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=13
        elif type=='WineT':
            actions,datas=self.Third_Wine()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=13
        elif type=='SpliceG':
            actions,datas=self.Splice_global()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=3
            self.attributes=60
        elif type=='SpliceF':
            actions,datas=self.Splice_First()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=60
        elif type=='SpliceS':
            actions,datas=self.Splice_Second()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=60
        elif type=='SpliceT':
            actions,datas=self.Splice_Third()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=60
        elif type=='WaveG':
            actions,datas=self.Wave_global()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=3
            self.attributes=40
        elif type=='WaveF':
            actions,datas=self.Wave_First()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=40
        elif type=='WaveS':
            actions,datas=self.Wave_Second()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=40
        elif type=='WaveT':
            actions,datas=self.Wave_Third()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=40
        elif type=='Australia_1':
            actions,datas=self.Australian_level1()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=14
        elif type=='German_1':
            actions,datas=self.German_level_1()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=24
        elif type=='Lung_Cancer_1':
            actions,datas=self.Lung_Cancer_level_1()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=56
        elif type=='Hill_Vally_without_noise_1':
            actions,datas=self.Hill_vally_without_noise_level_1()
            self.produced_actions=actions
            self.state=datas
            self.Whole_state=copy.deepcopy(datas)
            self.Whole_action=copy.deepcopy(actions)
            self.actions=2
            self.attributes=100


    def random_state_action(self):
        id=random.randint(0,len(self.state)-1)
        #print self.state[id], self.actions[id]
        return self.state[id], self.produced_actions[id]

    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information 

    def global_wine(self):
        attribute=13
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Wine.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            actions.append(int(first_inf[0])-1)
            temp=[]
            for i in range(1,len(first_inf)):
                temp.append(float(first_inf[i]))
            datas.append(temp)       
        return actions,datas

    def global_Australian(self):
        attribute=14
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Australian.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(' ')
            actions.append( int(first_inf[-1]))
            temp=[]
            for i in range(0,len(first_inf)-1):
                temp.append(float(first_inf[i]))
            datas.append(temp)

        return actions,datas

    def calculate_float_size(self):
        set_size=2
        for data in self.state:
            for da in data:
                if '.' in str(da):
                    size=len(str(da).split('.')[-1])
                    if size>=set_size:
                        set_size=size+1
        return set_size

    def global_Zoo(self):
        attribute=16
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Zoo.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            #print first_inf
            actions.append( int(first_inf[-1])-1)
            temp=[]
            for i in range(1,len(first_inf)-1):
                temp.append(float(first_inf[i]))
            datas.append(temp)

        return actions,datas

    def global_German(self):
        attribute=24
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\German.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(' ')
            inf=[]
            for f_inf in first_inf:
                if f_inf !='':
                    inf.append(f_inf)
            #print inf
            actions.append( int(inf[-1])-1)
            temp=[]
            for i in range(1,len(inf)-1):
                temp.append(float(inf[i]))
            datas.append(temp)
        #print actions
        #print datas
        return actions,datas

    def global_Ionosphere(self):
        attribute=34
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Ionosphere.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            #print first_inf[-1]
            if (first_inf[-1])=='g':
                actions.append(0)
            else:
                actions.append(1)
            temp=[]
            for i in range(0,len(first_inf)-1):
                temp.append(float(first_inf[i]))
            datas.append(temp)

        #print actions
        #print datas
        return actions,datas

    def global_Sonar(self):
        attribute=60
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Sonar.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            #print first_inf[-1]
            if (first_inf[-1])=='R':
                actions.append(0)
            else:
                actions.append(1)
            temp=[]
            for i in range(0,len(first_inf)-1):
                temp.append(float(first_inf[i]))
            datas.append(temp)
        #print actions
        #print datas
        return actions,datas

    def global_abalone(self):
        attribute=8
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\abalone.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            actions.append( int(first_inf[-1])-1)
            temp=[]
            if first_inf[0]=='M':
                temp.append(0)
            elif first_inf[0]=='F':
                temp.append(1)
            elif first_inf[0]=='I':
                temp.append(2)
            for i in range(1,len(first_inf)-1):
                temp.append(float(first_inf[i]))

            datas.append(temp)
        #print actions
        #print datas
        return actions,datas

    def global_WBCD(self):
        attribute=8
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\WBCD.txt')
        for raw_inf in raw_information:
            if not '?' in raw_inf:
                first_inf= raw_inf.split('\n')[0].split(',')
                if first_inf[-1]=='2':
                    actions.append(0)
                elif first_inf[-1]=='4':
                    actions.append(1)
                temp=[]
                for i in range(1,len(first_inf)-1):
                    temp.append(float(first_inf[i]))

                datas.append(temp)
        #print actions
        #print datas
        return actions,datas

    def global_Lung_Cancer(self):
        attribute=8
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Lung_Cancer.txt')
        for raw_inf in raw_information:
            if not '?' in raw_inf:
                first_inf= raw_inf.split('\n')[0].split(',')
                actions.append(int(first_inf[0])-1)
                temp=[]
                for i in range(1,len(first_inf)):
                    temp.append(float(first_inf[i]))

                datas.append(temp)
        #print actions
        #print datas
        return actions,datas

    def global_Lung_Hill_vally_without_noise(self):
        attribute=100
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Hill_Vally_without_noise.txt')
        for raw_inf in raw_information:
            if not '?' in raw_inf:
                first_inf= raw_inf.split('\n')[0].split(',')
                actions.append(int(first_inf[-1]))
                temp=[]
                for i in range(0,len(first_inf)-1):
                    temp.append(float(first_inf[i]))

                datas.append(temp)
        #print actions
        #print datas
        return actions,datas

    def First_IRIS(self):
        attribute=4
        
        IRIS=self.Read_CSV('R_env\\iris_id.csv')
        datas=[]
        actions=[]
        for i in range(0,len(IRIS)):
            data=[]
            for j in range(0,attribute):
                data.append(float(IRIS[i][j]))
            datas.append(data)
            if IRIS[i][attribute]=='1':
                actions.append(1)
            elif IRIS[i][attribute]=='2':
                actions.append(0)
            elif IRIS[i][attribute]=='3':
                actions.append(0)
        #print actions
        #print datas
        return actions,datas

    def Second_IRIS(self):
        attribute=4
        
        IRIS=self.Read_CSV('R_env\\iris_id.csv')
        datas=[]
        actions=[]
        for i in range(0,len(IRIS)):
            data=[]
            for j in range(0,attribute):
                data.append(float(IRIS[i][j]))
            datas.append(data)
            if IRIS[i][attribute]=='1':
                actions.append(0)
            elif IRIS[i][attribute]=='2':
                actions.append(1)
            elif IRIS[i][attribute]=='3':
                actions.append(0)
        #print actions
        #print datas
        return actions,datas

    def Third_IRIS(self):
        attribute=4
        
        IRIS=self.Read_CSV('R_env\\iris_id.csv')
        datas=[]
        actions=[]
        for i in range(0,len(IRIS)):
            data=[]
            for j in range(0,attribute):
                data.append(float(IRIS[i][j]))
            datas.append(data)
            if IRIS[i][attribute]=='1':
                actions.append(0)
            elif IRIS[i][attribute]=='2':
                actions.append(0)
            elif IRIS[i][attribute]=='3':
                actions.append(1)
        #print actions
        #print datas
        return actions,datas

    """
    def First_Wine(self):
        self.actions=3
        self.attributes=13
        actions,datas=self.global_wine()
        self.produced_actions=actions
        self.state=datas
        self.Whole_state=copy.deepcopy(datas)
        self.Whole_action=copy.deepcopy(actions)
        self.Build_Training_Data_set(7)
        actions=copy.deepcopy(self.produced_actions)
        datas=copy.deepcopy(self.state)
        for i in range(0,len(actions)):
            if actions[i]==0:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Second_Wine(self):
        self.actions=3
        self.attributes=13
        actions,datas=self.global_wine()
        self.produced_actions=actions
        self.state=datas
        self.Whole_state=copy.deepcopy(datas)
        self.Whole_action=copy.deepcopy(actions)
        self.Build_Training_Data_set(7)
        actions=copy.deepcopy(self.produced_actions)
        datas=copy.deepcopy(self.state)
        for i in range(0,len(actions)):
            if actions[i]==1:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Third_Wine(self):
        self.actions=3
        self.attributes=13
        actions,datas=self.global_wine()
        self.produced_actions=actions
        self.state=datas
        self.Whole_state=copy.deepcopy(datas)
        self.Whole_action=copy.deepcopy(actions)
        #print self.produced_actions
        self.Build_Training_Data_set(7)
        actions=copy.deepcopy(self.produced_actions)
        datas=copy.deepcopy(self.state)
        for i in range(0,len(actions)):
            if actions[i]==2:
                actions[i]=1
            else:
                actions[i]=0
        #print actions
        return actions,datas
   """
    def First_Wine(self):
        actions,datas=self.global_wine()
        for i in range(0,len(actions)):
            if actions[i]==0:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Second_Wine(self):
        actions,datas=self.global_wine()
        for i in range(0,len(actions)):
            if actions[i]==1:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Third_Wine(self):
        actions,datas=self.global_wine()
        for i in range(0,len(actions)):
            if actions[i]==2:
                actions[i]=1
            else:
                actions[i]=0
        #print actions
        return actions,datas

    def Build_Training_Data_set(self,id):
        action_size=[]
        action_member=[]
        for i in range(0,self.actions):
            temp=0
            m_temp=[]
            action_size.append(temp)
            action_member.append(m_temp)


        for i in range(0,len(self.produced_actions)):
            action_size[self.produced_actions[i]]=action_size[self.produced_actions[i]]+1
            action_member[self.produced_actions[i]].append(i)

        for i in range(0,self.actions):
            action_size[i]= int(action_size[i]/10)

        split_set=[]
        for i in range(0,10):
            temp=[] 
            split_set.append(temp)
            
        for i in range(0,10):
            if i !=9:
                for j in range(0,self.actions):
                    for num in range(0,action_size[j]):
                        split_set[i].append(action_member[j][num])
                        action_member[j].remove(action_member[j][num])
            else:
                for j in range(0,self.actions):
                    for num in range(0,len(action_member[j])):
                        split_set[i].append(action_member[j][num])

        #test set
        #id=random.randint(0,9) 
        self.state=[]
        self.produced_actions=[]
        for i in range(0,10):
            if i<id:
               for num in split_set[i]:
                   self.state.append(self.Whole_state[num])  
                   self.produced_actions.append(self.Whole_action[num])


    def Splice_global(self):
        attribute=60
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\splice.data')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            if first_inf[-1]=='EI':
                actions.append(0)
            elif first_inf[-1]=='IE':
                actions.append(1)
            elif first_inf[-1]=='N':
                actions.append(2)
            temp=[]
            for i in range(1,len(first_inf)-1):
                    temp.append(float(first_inf[i]))

            datas.append(temp)          
        return actions,datas

    def Splice_First(self):
        attribute=60
        datas=[]
        actions=[]
        actions,datas=self.Splice_global()
        for i in range(0,len(actions)):
            if actions[i]==0:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Splice_Second(self):
        attribute=60
        datas=[]
        actions=[]
        actions,datas=self.Splice_global()
        for i in range(0,len(actions)):
            if actions[i]==1:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Splice_Third(self):
        attribute=60
        datas=[]
        actions=[]
        actions,datas=self.Splice_global()
        for i in range(0,len(actions)):
            if actions[i]==2:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Wave_global(self):
        attribute=60
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\wave.data')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(',')
            actions.append(int(first_inf[-1]))
            temp=[]
            for i in range(1,len(first_inf)-1):
                    temp.append(float(first_inf[i]))

            datas.append(temp)          
        return actions,datas


    def Wave_First(self):
        attribute=40
        datas=[]
        actions=[]
        actions,datas=self.Wave_global()
        for i in range(0,len(actions)):
            if actions[i]==0:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Wave_Second(self):
        attribute=40
        datas=[]
        actions=[]
        actions,datas=self.Wave_global()
        for i in range(0,len(actions)):
            if actions[i]==1:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas

    def Wave_Third(self):
        attribute=40
        datas=[]
        actions=[]
        actions,datas=self.Wave_global()
        for i in range(0,len(actions)):
            if actions[i]==2:
                actions[i]=1
            else:
                actions[i]=0
        return actions,datas
 
    def Australian_level1(self):
        attribute=14
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Australia_1.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(' ')
            actions.append( int(first_inf[-1]))
            temp=[]
            for i in range(0,len(first_inf)-1):
                temp.append(float(first_inf[i]))
            datas.append(temp)
        return actions,datas

    def German_level_1(self):
        attribute=24
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\German_1.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(' ')
            inf=[]
            for f_inf in first_inf:
                if f_inf !='':
                    inf.append(f_inf)
            #print inf
            actions.append( int(inf[-1]))
            temp=[]
            for i in range(1,len(inf)-1):
                temp.append(float(inf[i]))
            datas.append(temp)
        #print actions
        #print datas
        return actions,datas

    def Lung_Cancer_level_1(self):
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Lung_Cancer_1.txt')
        for raw_inf in raw_information:
            first_inf= raw_inf.split('\n')[0].split(' ')
            actions.append(int(first_inf[-1])-1)
            temp=[]
            for i in range(0,len(first_inf)-1):
                temp.append(float(first_inf[i]))
            datas.append(temp)
        #print len(actions)
        #print len(datas)
        return actions,datas

    def Hill_vally_without_noise_level_1(self):
        attribute=100
        datas=[]
        actions=[]
        raw_information=self.Read_Information('R_env\\Hill_Vally_without_noise_1.txt')
        for raw_inf in raw_information:
            if not '?' in raw_inf:
                first_inf= raw_inf.split('\n')[0].split(' ')
                actions.append(int(first_inf[-1]))
                temp=[]
                for i in range(0,len(first_inf)-1):
                    temp.append(float(first_inf[i]))

                datas.append(temp)
        #print actions
        #print datas
        return actions,datas


    #Test code
class environment_test:
    def __init__(self):
        self.env=environment()
        
        state=self.env.Create_Set_condition(20)
        print (state)
        print (self.env.executeAction(0,state,1))
        print (self.env.executeAction(1,state,1))
        print (self.env.executeAction(2,state,1))
        print (self.env.executeAction(3,state,1))

#e_t=environment_test()
r=R_environment(21,1)
#print r.random_state_action()