﻿import random
import uuid
import os
#import time
import copy
from Config import standard_XCS_config
from OIS_Config import OIS_Global_Config
from environment import environment
from environment import R_environment
import multiprocessing
#import math

################# global parameters ##################
Is_LinuX=False
test_fold=8
#env=environment()
#problem_type=0 #[0:Multiplexer, 1:Carry, 2:Even parity 3: Majority On]
#problem_length=6

################## Setting for real value problems #################
R_problem_Type=0
#[0:IrisG,1:wineG,2:Australian,3:Zoo 4:German,5:Ionosphere,6:Sonar,7:abalone,8: WBCD,9 lung cancer,10 Hill_Vally_without_noise,
#11:First Iris, 12:second iris 13:third iris 14 First Wine, 15 Second Wine, 16 Third Wine, 17 splice, 18 splicefirst 19 splicesecond,
# 20 splicethird, 21 wave, 22wave first, 23 wave second, 24 wave third, 25 Australia_1,26 German_1 ,27 Lung_Cancer_1,
#28 Hill_Vally_without_noise_1]

R_env=R_environment(R_problem_Type,test_fold)
#print R_env.actions
config=standard_XCS_config()
OIS_config=OIS_Global_Config()
"""
########old version [upper,lower###########
P_extend_High=[0.1,1.0]
P_extend_Low=[-1.0,-0.1]
P_extend_P_High=1.1
P_extend_P_Low=1.1
crossover_rate=0.5
mutation_size=[-1,1]
round_number=R_env.round_set_size
#savefolder='XCS_RESULT.txt'
"""
###########ALKR Setting############
P_DONTCARE=0.33#probability of ignore attribute

#for the lowest (dataset)
global_low=R_env.low
# the up
global_up=R_env.up
#extend range for cover
P_extend=[0,0.5]
#the kept float
round_number=R_env.round_set_size
#for mutation
mutation_size=[-0.5,0.5]

#add/remove activer
add_activer=True
remove_activer=True




##iterations and population setting #############

maxPopSize=3000 #max population
maxproblemsize=30*1000 #iteration for shrink

Test_record_step=500#for recording training accuracy
Test_records=[]


################### Time recoder ##############
#recode the bbegin time
def Header():
    format_time,Hour,Min,second=config.startTimer()
    print ("Start Time:",format_time)
    return Hour,Min,second

#recode the finish time    
def Exit(Hour,Min,second):
    format_time_1,Hour_1,Min_1,second_1=config.startTimer()
    print ("shutting down")
    print ("finish time: ",format_time_1)
    use_time=config.elapsed(Hour_1,Hour,Min_1,Min,second_1,second)
    print (use_time, "second")
    return use_time

############## Build Hash IDs #####################3
def Initial_Hash():
    Hash_Table=[]
    ID=0
    Limitation=maxPopSize+2*R_env.actions+20
    for i in range(0,Limitation):
        Hash_Table.append(ID)
        ID=ID+1
    return Hash_Table



def Build_Hash_ID():
    Hash=random.choice(Unused_Hash)
    #print Unused_Hash
    Unused_Hash.remove(Hash)
    used_Hash.append(Hash)
    #print used_Hash
    #print Hash
    #print len(Unused_Hash)
    return Hash

def Fresh_Hash_Id(Hash):
    Unused_Hash.append(Hash)
    #print Unused_Hash
    used_Hash.remove(Hash)

#print Unused_Hash[0], Unused_Hash[-1] 

################ Create classifiers ##################
    #condition: state from environment
    #action: 0 or 1
    #setsize: action set size
    #time: the time use 


def ALKR_Create_Init_Classifier(population,condition,attribute_list,action,setsize,time,uuid_key):
    classifier={'condition':condition,
                'attribute':attribute_list,
                    'action':action,
                    'prediction': 10.0,#config.predictionIni,
                    'predictionError':0.0,#config.predictionErrorIni,
                    'accuracy':0.01,#config.fitnessIni,
                    'fitness':0.01,#config.fitnessIni,
                    'numerosity':1,
                    'experience':0.0,
                    'actionSetSize':setsize,
                    'timeStamp':time,  
                    'uuid_key':uuid_key,                 
                    }
    population.setdefault(uuid_key,classifier)
    return uuid_key

def ALKR_attributes(up,low):
    classifier={
                'Upper':up,
                'Lower':low            
                    }
    return classifier

############### Create Match set ####################

#compare_set: [state, population]

#Judge whether state match the condition in classifier if match return true otherwise return false

def ALKRisConditionMatched_P(compare_set):
        for i in compare_set[1]['attribute']:
            if compare_set[0][i]>compare_set[1]["condition"][i]['Upper'] or compare_set[0][i]<compare_set[1]["condition"][i]['Lower']:
                return None
        return compare_set[1]['uuid_key']

def ALKRisConditionMatched_S(attribute_list,condition,state):
        for i in attribute_list:
            if state[i]>condition[i]['Upper'] or state[i]<condition[i]['Lower']:
                return False
        return True
#create a condition which can match the input state

def ALKR_createMatchingCondition(state):
    conditionlist=set([])
    while len(conditionlist)<1:
        for i in range(0,len(state)):
            if(random.random()>P_DONTCARE):
                conditionlist.add(i)

    condition={}

    for num in conditionlist:
        upsize=global_up[num]-state[num]
        lowsize=state[num]-global_low[num]
        #up 
        up=round(state[num]+random.uniform(P_extend[0],P_extend[1])*upsize,round_number)
        #low
        low=round(state[num]-random.uniform(P_extend[0],P_extend[1])*lowsize,round_number)
        attribute=ALKR_attributes(up,low)
        condition.setdefault(num,attribute)
    #print condition
    return condition,conditionlist

#Returns the number of actions in the set and returns which action is covered
def nrActionsInSet(match_set,population):
    nr=0
    coveredActions=[]
    #self.config.numActions
    for i in range(0,2):
        coveredActions.append(False)
        #print coveredActions
    for cl in match_set:
        #self.config.numActions
        if nr<2:
           if coveredActions[population[cl]['action']]==False:
               coveredActions[population[cl]['action']]=True
               nr=nr+1
        else:
            return nr,coveredActions
    return nr,coveredActions

def R_nrActionsInSet(match_set,population):
    nr=0
    coveredActions=[]
    #self.config.numActions
    for i in range(0,R_env.actions):
        coveredActions.append(False)
        #print coveredActions
    for cl in match_set:
        #self.config.numActions
        if nr<R_env.actions:
           if coveredActions[population[cl]['action']]==False:
               coveredActions[population[cl]['action']]=True
               nr=nr+1
        else:
            return nr,coveredActions
    return nr,coveredActions

#build a classifier which match the input instance

def ALKR_matchingCondAndSpecifiedAct(population,state,action,setSize,time):   
    condition,attributelist=ALKR_createMatchingCondition(state)
    uuid_key=Build_Hash_ID()
    #Create_Init_Classifier(population,condition,action,setSize,time,uuid_key)
    ALKR_Create_Init_Classifier(population,condition,attributelist,action,setSize,time,uuid_key)
    return uuid_key

# Gets the match-set that matches state from pop.
# If a classifier was deleted, record its address in killset to be
# able to update former actionsets.
# The iteration time 'itTime' is used when creating a new classifier
# due to covering. Covering occurs when not all possible actions are
# present in the match set. Thus, it is made sure that all actions
# are present in the match set.
def getMatchSet(population,state,itTime,pool):
    popSize=0
    setSize=0
    #print "begin"
    parameters=[]
    #calculate the population size

    #Box the parameters for parallel computing
    for i in population:
        temp=[]
        temp.append(state)
        temp.append(population[i]) 
        popSize=popSize+population[i]['numerosity']      
        parameters.append(temp)
    #use parallel computing to  match input state and classifier rules
    Candidate_match_set=pool.map(ALKRisConditionMatched_P,parameters)

    match_set=[]

    #calculate size of the match set
    for i in Candidate_match_set:
        if i!=None:
            match_set.append(i)
            setSize=setSize+population[i]['numerosity']
    #print (popSize)
    #print (setSize)
    #print (match_set)
    representedActions,coveredActions=R_nrActionsInSet(match_set,population) 
    #print representedActions,coveredActions  
    # create covering classifiers, if not all actions are covered 
    # self.config.numActions
    while (representedActions<R_env.actions):
        #print popSize,self.maxPopSize
        #time.sleep(10)
        #make sure that all actions are covered
        #self.config.numActions
        for i in range(0,R_env.actions):
            if coveredActions[i]==False:
                new_match_Id=ALKR_matchingCondAndSpecifiedAct(population,state,i,setSize+1,itTime)
                setSize=setSize+1
                popSize=popSize+1
                match_set.append(new_match_Id)
        # Delete classifier if population is too big and record it in killset
        while (popSize>maxPopSize):
                #print popSize,self.maxPopSize
                #print popSize
                #print self.maxPopSize
                deleteStochClassifier_match_set(population,pool,match_set)
                popSize=popSize-1
        representedActions,coveredActions=R_nrActionsInSet(match_set,population)
    #print (representedActions,coveredActions)
    #print (len(population))
    #print (match_set)
    return match_set

#Delete the marked classifier from the classifier set and match set
def deleteTypeofClassifier_match_set(population,uuid_number,match_set):
    if population[uuid_number]['numerosity']>1:
        population[uuid_number]['numerosity']=population[uuid_number]['numerosity']-1
    else:
        Fresh_Hash_Id(uuid_number)
        del population[uuid_number]
        if uuid_number in match_set:
            match_set.remove(uuid_number)
        

def deleteStochClassifier_match_set(population,pool,match_set):
    sum_value=0.0
    prop_list=[]
    choicep=0.0
    meanf=0.0
    size=0
    locations=[]
    location=0
    #get the sum of the fitness and the numerosity
    for i in population:
        meanf=meanf+population[i]['fitness']
        size=size+population[i]['numerosity']
        locations.append(i)
    meanf=1.0*meanf/size
    parameters=[]

    for i in population:
        temp=[]
        temp.append(population[i])
        temp.append(meanf)
        parameters.append(temp)

    #get the delete proportion, which depends on the average fitness

    # calculate which classifier rule should be deleted
    
    prop_list=pool.map(getDelProp,parameters)
    parameters=[]
    #print (prop_list)
    sum_value=sum(prop_list)
    #choose the classifier that will be deleted
    choicep=random.random()*sum_value

    #look for the classifier that will be deleted
    sum_threshold=prop_list[0]
    while sum_threshold<choicep:
          location=location+1
          sum_threshold=sum_threshold+prop_list[location]

        #print 'location',location
        #print 'sum',sum
        #print 'choicep',choicep
        #print 'meanf',meanf
        #print 'size',size
        #return result, location
    deleteTypeofClassifier_match_set(population,locations[location],match_set)

#return the vote for deletion of the classifier
#parameters [population,meanfitness]
def getDelProp(parameters):
    average_fitness=1.0*parameters[0]['fitness']/parameters[0]['numerosity']
        #print average_fitness
        #average_fitness>=config.delta*meanFitness or population['experience']<config.theta_del
    if average_fitness>=0.1*parameters[1] or parameters[0]['experience']<20:
       result= 1.0*parameters[0]['actionSetSize']*parameters[0]['numerosity']
       return result
    else:
       result= 1.0*parameters[0]['actionSetSize']*parameters[0]['numerosity']*parameters[1]/average_fitness            
  
       return result

######################### prediction array operations ############################################
#determines the prediction array out of the match set (match set should never be None)
def getPredictionArray(population,match_set):
    predictionArray=[]
    sumClfrFitnessInPredictionArray=[]
    #self.config.numActions
    for i in range(0,R_env.actions):
        predictionArray.append(0.0)
        sumClfrFitnessInPredictionArray.append(0.0)

    for i in match_set:
        predictionArray[int(population[i]['action'])]= predictionArray[int(population[i]['action'])]+population[i]['prediction']* population[i]['fitness']
        sumClfrFitnessInPredictionArray[int(population[i]['action'])]=sumClfrFitnessInPredictionArray[int(population[i]['action'])]+population[i]['fitness']
    #self.config.numActions
    for i in range(0,R_env.actions):
        if sumClfrFitnessInPredictionArray[i]!=0:
            predictionArray[i]=predictionArray[i]/sumClfrFitnessInPredictionArray[i]
        else:
            predictionArray[i]=0
    return predictionArray,sumClfrFitnessInPredictionArray

#selects an action randomly. The function assures that chosen action is represented by at least one classifier in the prediction array        
def randomActionWinner(sumClfrFitnessInPredictionArray):
    ret=0
    #self.config.numActions

    ret=random.randint(0,R_env.actions-1)
    while sumClfrFitnessInPredictionArray[ret]==0:
            #self.config.numActions
            ret=random.randint(0,R_env.actions-1)
    return ret

#select the action in the prediction array with the best value
def bestActionWinner(predictionArray):
    ret=0
    #self.config.numActions
    for i in range(1,R_env.actions):
        if predictionArray[ret]<predictionArray[i]:
            ret=i
    return ret

######################## action set operations #########################################
#constructs an action set out of the match set ms
def getActionSet(population,action,match_set):
    action_set=[]
    for i in match_set:
        if action== population[i]['action']:
            action_set.append(i)
    return action_set

# Updates all parameters in the action set.
# Essentially, reinforcement Learning as well as the fitness evaluation takes place in this set.
# Moreover, the prediction error and the action set size estimate is updated. Also,
# action set subsumption takes place if selected. As in the algorithmic description, the fitness is updated
# after prediction and prediction error. However, in order to be more conservative the prediction error is
# updated before the prediction.
# @param maxPrediction The maximum prediction value in the successive prediction array (should be set to zero in single step environments).
# @param reward The actual resulting reward after the execution of an action.
def updateActionSet(population,max_prediction,reward,action_set,pool):
    P=0.0
    setsize=0.0
    #P=reward+self.config.gama*max_prediction
    P=reward+config.gama*max_prediction


    for i in action_set:
        setsize= setsize+population[i]['numerosity']
        population[i]['experience']=population[i]['experience']+1

    #(important)update prediction, prediction error and action set size estimate
    for i in action_set:
            #first adjustments: simply calculate the average
            #self.config.beta
            if population[i]['experience']<(1.0/config.beta):
                population[i]['predictionError']=(population[i]['predictionError']*(float(population[i]['experience'])-1.0)+abs(P-population[i]['prediction']))/float(population[i]['experience'])
                #print "predictionError",classifier_set[i].predictionError
                population[i]['prediction']=((population[i]['prediction']*(float(population[i]['experience'])-1.0))+P)/float(population[i]['experience'])
                #print "prediction",classifier_set[i].prediction
                population[i]['actionSetSize']=((population[i]['actionSetSize'] * (float(population[i]['experience'])-1.0))+setsize)/float(population[i]['experience'])
                #print "actionSetSize",classifier_set[i].actionSetSize
            #normal adjustment: use widrow hoff delta rule
            else:
                population[i]['predictionError']=population[i]['predictionError']+config.beta*(abs(P-population[i]['prediction'])-population[i]['predictionError'])
                #print "predictionError",classifier_set[i].predictionError
                population[i]['prediction']=population[i]['prediction']+config.beta*(P-population[i]['prediction'])
                #print "prediction",classifier_set[i].prediction
                population[i]['actionSetSize']=population[i]['actionSetSize']+config.beta*(setsize-population[i]['actionSetSize'])
    #print "actionSetSize",classifier_set[i].actionSetSize

    updateFitness(population,action_set)


    if(config.doActSetSubsumption):
        doActionSetSubsumption(population,action_set)

#update the fitnesses of an action set (the previous[A] in multi-step envs or the current [A] in single-step envs
def updateFitness(population,action_set):
    ksum=0.0
    #if the action set got NULL (due to deletion) return
    if len(action_set)==0:
       return 

     #First, calculate the accuracies of the classifier and the accuracy sums
    for i in action_set:
        if population[i]['predictionError']<=config.epsilon_0:
            population[i]['accuracy']=1.0
        else:
            population[i]['accuracy']=config.alpha*pow(population[i]['predictionError']/config.epsilon_0,-(config.nu))
            #population[i]['accuracy']=config.alpha*pow(-(config.nu),population[i]['predictionError']/config.epsilon_0)

        ksum=ksum+population[i]['accuracy']*float(population[i]['numerosity'])

        #Next, update the fitnesses accordingly
    for i in action_set:
        population[i]['fitness']=population[i]['fitness']+config.beta*((population[i]['accuracy']*population[i]['numerosity'])/ksum-population[i]['fitness'])

################################ subsumption deletion #################################
#Check if the first condition is more general than the second.
#It is made sure that the classifier is indeed more general and not equally general
#as well as that the more specific classifier is completely included in the more general one (do not specify overlapping regions).


def R_isMoreGeneral(Gener_condition,Gener_conditionlist,Specific_condition,Specific_conditionlist):
    
    if not Gener_conditionlist.issubset( Specific_conditionlist):
        return False

    for i in Gener_conditionlist:
        #config.dontcare
        if Specific_condition[i]['Upper']>Gener_condition[i]['Upper'] or Specific_condition[i]['Lower']<Gener_condition[i]['Lower']:
            return False                                                                                                                 
            
    return True

#parameters[condition_most_sumber,population]
def isMoreGeneral_parallel(parameter):
    answer=False
    for i in range(0,len(parameter[0])):
            #config.dontcare
        if parameter[0][i]!='#' and parameter[0][i] !=parameter[1]['condition'][i]:
            return None
        elif parameter[0][i]!=parameter[1]['condition'][i]:
            answer=True
    if answer:
        return parameter[1]['uuid_key']
    else:
        return None

def isSubsumer(population,uuid):
    result= int(population[uuid]['experience'])>config.theta_sub and population[uuid]['predictionError']<=config.epsilon_0
    return result


def doActionSetSubsumption(population,action_set):
    subsumer=None
    #find the most general subsumer
    for i in action_set:            
       if(isSubsumer(population,i)):
           if(subsumer==None):
               subsumer=i
           elif(R_isMoreGeneral(population[i]['condition'],population[subsumer]['condition'])):
                subsumer=i
        
        #If a subsumer was found, subsume all classifiers that are more specific
    if subsumer!= None:
       for i in action_set:
         if i != subsumer:
            if(R_isMoreGeneral(population[subsumer]['condition'],population[i]['condition'])):                
                population[subsumer]['numerosity']=population[subsumer]['numerosity']+population[i]['numerosity']
                del population[i]
                action_set.remove(i)
                Fresh_Hash_Id(i)


############################ discovery mechanism #########################################
    #selects a classifier from 'set' using tourment selection
    #If 'notMe' is not the Null and forceDifferentInTournament is set to a value larger 0,
    # this classifier is not selected except if it is the only classifier.
    
def selectClassifierUsingTournamentSelection(action_set,population):
    winnerSet=[]
    fitness=-1.0

    #there must be at least one classifier in the set
    #if classifierset==None or len(classifierset)==0:
    #    print "in selectClassifierUsingTournamentSelection classifierset mustn't be None"
        

     #only one classifier in set
    if len(action_set)==1:
        return action_set[0]

    #tournament with fixed size
    #tournament selection with the tournament size approx. equal to tournamentSize setsum
    while len(winnerSet)==0: 
        for i in action_set:
            #if his fitness is worse then do not bother
            if len(winnerSet)==0 or  (fitness-config.selecTolerance) <= (population[i]['fitness']/population[i]['numerosity']):
                for j in range(0,population[i]['numerosity']):
                    if random.random()<config.tournametSize:
                        if len(winnerSet)==0:
                                #the first one
                            winnerSet.append(i)
                            fitness=population[i]['fitness']/population[i]['numerosity']

                        else:
                            if (fitness+config.selecTolerance) > (population[i]['fitness']/population[i]['numerosity']) :
                                winnerSet.append(i)

                            else:
                                winnerSet=[]
                                winnerSet.append(i)
                                fitness=population[i]['fitness']/population[i]['numerosity']
                        break

        #print winnerSet
    if len(winnerSet)>1:
            size=random.randint(0,len(winnerSet)-1)
            return winnerSet[size]
    return winnerSet[0]     

# create an offspring 
def ALKR_Create_off_spring_Classifier(condition,attribute_list,action,setsize,time_stamp,prediction,prediction_Error,accuracy,fitness):
    uuid_key=Build_Hash_ID()
    classifier={'condition':condition,
                'attribute':attribute_list,
                    'action':action,
                    'prediction': prediction,#config.predictionIni,
                    'predictionError':prediction_Error,#config.predictionErrorIni,
                    'accuracy':accuracy,#config.fitnessIni,
                    'fitness':fitness,#config.fitnessIni,
                    'numerosity':1,
                    'experience':0.0,
                    'actionSetSize':setsize,
                    'timeStamp':time_stamp,  
                    'uuid_key':uuid_key,                 
                    }
   
    return classifier


def ALKR_OnePointCrossover(Parent_1,Parent_2):
    Union_attribute=Parent_1['attribute']|Parent_2['attribute']
    intersection_attribute=Parent_1['attribute']& Parent_2['attribute']
    split_location= random.sample(Union_attribute,1)
    split_point=split_location[0]
    #print Union_attribute
    #print intersection_attribute
    #print split_location
    #print type(intersection_attribute)
    #print type(split_location)
    conditionlist_1=set([])
    conditionlist_2=set([])
    condition_1={}
    condition_2={}
    if split_point in intersection_attribute:
        #new condition_1
        for i in Parent_1['attribute']:
            if i<split_point:
                conditionlist_1.add(i)
                t_cond=ALKR_attributes(Parent_1['condition'][i]['Upper'],Parent_1['condition'][i]['Lower'])
                condition_1.setdefault(i,t_cond)

        for i in Parent_2['attribute']:
             if i>split_point:
                conditionlist_1.add(i)
                t_cond=ALKR_attributes(Parent_2['condition'][i]['Upper'],Parent_2['condition'][i]['Lower'])
                condition_1.setdefault(i,t_cond)

        split_low=Parent_1['condition'][split_point]['Lower']
        split_high=Parent_2['condition'][split_point]['Upper']

        if split_low>split_high:
            temp=split_low
            split_low=split_high
            split_high=temp
        conditionlist_1.add(split_point)
        t_cond=ALKR_attributes(split_high,split_low)
        condition_1.setdefault(split_point,t_cond)

        #new condition_2
        for i in Parent_1['attribute']:
            if i>split_point:
                conditionlist_2.add(i)
                t_cond=ALKR_attributes(Parent_1['condition'][i]['Upper'],Parent_1['condition'][i]['Lower'])
                condition_2.setdefault(i,t_cond)

        for i in Parent_2['attribute']:
             if i<split_point:
                conditionlist_2.add(i)
                t_cond=ALKR_attributes(Parent_2['condition'][i]['Upper'],Parent_2['condition'][i]['Lower'])
                condition_2.setdefault(i,t_cond)

        split_low=Parent_2['condition'][split_point]['Lower']
        split_high=Parent_1['condition'][split_point]['Upper']

        if split_low>split_high:
            temp=split_low
            split_low=split_high
            split_high=temp
        conditionlist_2.add(split_point)
        t_cond=ALKR_attributes(split_high,split_low)
        condition_2.setdefault(split_point,t_cond)
        
    else:
        for i in Parent_1['attribute']:
            if i<split_point:
                conditionlist_1.add(i)
                t_cond=ALKR_attributes(Parent_1['condition'][i]['Upper'],Parent_1['condition'][i]['Lower'])
                condition_1.setdefault(i,t_cond)
            else:
                conditionlist_2.add(i)
                t_cond=ALKR_attributes(Parent_1['condition'][i]['Upper'],Parent_1['condition'][i]['Lower'])
                condition_2.setdefault(i,t_cond)

        for i in Parent_2['attribute']:
            if i>split_point:
                conditionlist_1.add(i)
                t_cond=ALKR_attributes(Parent_2['condition'][i]['Upper'],Parent_2['condition'][i]['Lower'])
                condition_1.setdefault(i,t_cond)
            else:
                conditionlist_2.add(i)
                t_cond=ALKR_attributes(Parent_2['condition'][i]['Upper'],Parent_2['condition'][i]['Lower'])
                condition_2.setdefault(i,t_cond)


    #print conditionlist_1
    #print condition_1

    #print conditionlist_2
    #print condition_2
    return condition_1, conditionlist_1, condition_2,conditionlist_2

    #return condition_r1,condition_r2



#determines if crossover is applied and calls  then the selected crossover type
def ALKR_crossover(Parent_1,Parent_2):
    condition_1=copy.deepcopy(Parent_1['condition'])
    conditionlist_1=copy.deepcopy(Parent_1['attribute'])
    condition_2=copy.deepcopy(Parent_2['condition'])
    conditionlist_2=copy.deepcopy(Parent_2['attribute'])
    if random.random()<config.pX:
        condition_1, conditionlist_1, condition_2,conditionlist_2=ALKR_OnePointCrossover(Parent_1,Parent_2)
    return condition_1, conditionlist_1, condition_2,conditionlist_2

#Mutates the condition of the classifier. If one allele is mutated depends on the constant pM
#This mutation is a niche mutation. It assures that the resulting classifier still matches the current situation

def ALKR_applyNicheMutation(condition,attribute_list,state):
    for i in attribute_list:
        if random.random()<config.pM:
            size=condition[i]['Upper']-condition[i]['Lower']
            #if random.random()<0.5:
            temp_low=round(condition[i]['Lower']+size*random.uniform( mutation_size[0],mutation_size[1]),round_number)
            #else:
            #    temp_low=round(condition[2*i],round_number)

            #if random.random()<0.5:
            temp_high=round(condition[i]['Upper']+size*random.uniform( mutation_size[0],mutation_size[1]),round_number)
            #else:
            #    temp_high=round(condition[2*i+1],round_number)

            temp=0
            #guarantee upper and lower boundary
            if temp_high<temp_low:
                temp=temp_low
                temp_low=temp_high
                temp_high=temp

            #guarantee match at least one (gene scalpel)
            if state[i]>temp_high:
                upsize=global_up[i]-state[i]
                temp_high=round(state[i]+random.uniform(P_extend[0],P_extend[1])*upsize,round_number)

            if state[i]<temp_low:
                lowsize=state[i]-global_low[i]
                temp_low=round(state[i]-random.uniform(P_extend[0],P_extend[1])*lowsize,round_number)


            condition[i]['Lower']=temp_low
            condition[i]['Upper']=temp_high
    return condition

#Mutates the action of the classifier
def mutateAction(action):    
    result_action=action
    if random.random()<config.pM:
        while result_action==action:
            result_action=random.randint(0,R_env.actions-1)
    return result_action

def ALKR_mutation(condition,attribute_list,action,state):
    m_condition=ALKR_applyNicheMutation(condition,attribute_list,state)
    m_action=mutateAction(action)
    return m_action,m_condition

def ALKR_attribute_add_operator(condition,conditionlist,state):
    addition_list=[]
    for num in range(0,len(state)):
        if not num in conditionlist:
            if(random.random()<config.pM):
                addition_list.append(num)
                conditionlist.add(num)

    for num in addition_list:
        upsize=global_up[num]-state[num]
        lowsize=state[num]-global_low[num]
        #up 
        up=round(state[num]+random.uniform(P_extend[0],P_extend[1])*upsize,round_number)
        #low
        low=round(state[num]-random.uniform(P_extend[0],P_extend[1])*lowsize,round_number)
        attribute=ALKR_attributes(up,low)
        condition.setdefault(num,attribute)
    return condition,conditionlist

def ALKR_attribute_remove_operator(condition,conditionlist):
    remove_list=[]
    for num in conditionlist:
            if(random.random()<config.pM):
                remove_list.append(num)

    for num in remove_list:
        conditionlist.remove(num)
        del condition[num]
    return condition, conditionlist

def ALKR_Abortion(condition,conditionlist,state):
    if len(conditionlist)==0:
        return False
    for i in conditionlist:
        if state[i]>condition[i]['Upper'] or state[i]<condition[i]['Lower']:
                return False
    return True


#select two classifiers using chosen selection mechanism and copy them as offspring
def ALKR_selectTwoClassifiers(population,action_set,pool,state):
    parents=[]
    parent_1=selectClassifierUsingTournamentSelection(action_set,population)
    parent_2=selectClassifierUsingTournamentSelection(action_set,population)
    parents.append(parent_1)
    parents.append(parent_2)
    #calculate parameters
    fitness_0=population[parents[0]]['fitness']/float(population[parents[0]]['numerosity'])
    fitness_1=population[parents[1]]['fitness']/float(population[parents[1]]['numerosity'])
    prediction_offspring=1.0*(population[parents[0]]['prediction']+population[parents[1]]['prediction'])/2.0
    predictionError_offspring=1.0*config.predictionErrorReduction*((population[parents[0]]['predictionError']+population[parents[1]]['predictionError'])/2.0)
    fitness_offspring=config.fitnessReduction*((fitness_0+fitness_1)/2.0)
    #print fitness_offspring
    #print prediction_offspring
    #print predictionError_offspring
    
    #crossover condition
    offspring=[]
    condition_0, conditionlist_0, condition_1,conditionlist_1=ALKR_crossover(population[parents[0]],population[parents[1]])


    #mutation condition and action
    action_0=population[parents[0]]['action']
    action_1=population[parents[1]]['action']

    m_action_0,m_condition_0=ALKR_mutation(condition_0,conditionlist_0,action_0,state)
    m_action_1,m_condition_1=ALKR_mutation(condition_1,conditionlist_1,action_1,state)

    #Operators
    if add_activer==True:
        m_condition_0,conditionlist_0=ALKR_attribute_add_operator(m_condition_0,conditionlist_0,state)
        m_condition_1,conditionlist_1=ALKR_attribute_add_operator(m_condition_1,conditionlist_1,state)

    if remove_activer==True:
        m_condition_0,conditionlist_0=ALKR_attribute_remove_operator(m_condition_0,conditionlist_0)
        m_condition_1,conditionlist_1=ALKR_attribute_remove_operator(m_condition_1,conditionlist_1)


    #create offsprings
    if ALKR_Abortion(m_condition_0,conditionlist_0,state):               
        offspring_0=ALKR_Create_off_spring_Classifier(m_condition_0,conditionlist_0,m_action_0,population[parents[0]]['actionSetSize'],population[parents[0]]['timeStamp'],prediction_offspring,predictionError_offspring,population[parents[0]]['accuracy'],fitness_offspring)
        offspring.append(offspring_0)
        
    if ALKR_Abortion(m_condition_1,conditionlist_1,state):     
        offspring_1=ALKR_Create_off_spring_Classifier(m_condition_1,conditionlist_1,m_action_1,population[parents[1]]['actionSetSize'],population[parents[1]]['timeStamp'],prediction_offspring,predictionError_offspring,population[parents[1]]['accuracy'],fitness_offspring)
        offspring.append(offspring_1)    
    #parameters=[]
    return parents, offspring 


#check if classifier parent can subsumes off-spring
def subsumes(population,subsume_Id,offspring):
    result= population[subsume_Id]['action']==offspring['action'] and isSubsumer(population,
    subsume_Id) and R_isMoreGeneral(population[subsume_Id]['condition'],population[subsume_Id]['attribute'],
    offspring['condition'],offspring['attribute'])
    return result

#population: a single classifier rule
def isSubsumer_parallel_Discovery(population):
    #result= int(population[uuid]['experience'])>config.theta_sub and population[uuid]['predictionError']<=config.epsilon_0
    result= int(population['experience'])>20 and population['predictionError']<=10
    return result

#parameters[subsume,offspring]
def subsumes_parallel(parameters):
    result= parameters[0]['action']==parameters[1]['action'] and isSubsumer_parallel_Discovery(parameters[0]
    ) and R_isMoreGeneral(parameters[0]['condition'],parameters[0]['attribute'],parameters[1]['condition'],parameters[1]['attribute'])
    if result:
        return parameters[0]['uuid_key']
    else:
        return None

def isSameCondition(condition1,conditionlist_1,condition2,conditionlist_2):
    if not (conditionlist_1.issubset(conditionlist_2) and conditionlist_2.issubset(conditionlist_1)):
        return False
    for i in conditionlist_1:
        if condition1[i]['Upper']!=condition2[i]['Upper'] or condition1[i]['Lower']!=condition2[i]['Lower']:
            return False
    return True

def subsumeClassifierToSet(population,offspring,action_set,pool):
    parameters=[]
    for i in action_set:
        temp=[]
        temp.append(population[i])
        temp.append(offspring)
        parameters.append(temp)

    Candidate_Subsumers=pool.map(subsumes_parallel,parameters)
    Subsumers=[]
    for can in Candidate_Subsumers:
       if can!=None:
           Subsumers.append(can)
    #free the parameter       
    parameters=[]            
    if len(Subsumers)>0:
       #print len(Subsumers)
       numSub=random.randint(0,len(Subsumers)-1)
       #print offspring['uuid_key']
       Fresh_Hash_Id(offspring['uuid_key'])
       population[Subsumers[numSub]]['numerosity']=population[Subsumers[numSub]]['numerosity']+1
        
       #print len(Subsumers),'   ',numSub
       return True
    return False

#CHeck is this offspring rule exist in the population
#parameters[population,offspring]
def Is_population_has_offspring(parameters):
    result=parameters[0]['action']==parameters[1]['action'] and isSameCondition(
        parameters[0]['condition'],parameters[0]['attribute'],
        parameters[1]['condition'],parameters[1]['attribute'])
    if result:
        return parameters[0]['uuid_key']
    else:
        return None


#add the classifier rule into the population
def addclassifierToSet(population,offspring,pool):
    #check if the classifier exists already. If so, just increase the numerosity and free the space of the new classifier
    parameters=[]
    for i in population:
        temp=[]
        temp.append(population[i])
        temp.append(offspring)
        parameters.append(temp)
    same_cl=None
    Candidate_cl=pool.map(Is_population_has_offspring,parameters)
    for can in Candidate_cl:
        if can!=None:
            same_cl=can
            break
    #free the parameters
    parameters=[]
    if same_cl!=None:
        #print same_cl
        #print offspring['uuid_key']
        
        Fresh_Hash_Id(offspring['uuid_key']) 
        #print '============================='
        #print used_Hash
        #print Unused_Hash
        #print '============================='
        population[same_cl]['numerosity']=population[same_cl]['numerosity']+1
        
    else:
        population.setdefault(offspring['uuid_key'],offspring)
        #print offspring['uuid_key']

def subsumeClassifier(population,offspring,parents,action_set,pool):  
    #check can parents subsume the offspring 
    
    for i in range(0,2):
        s_result=subsumes(population,parents[i],offspring)
        if s_result:
          Fresh_Hash_Id(offspring['uuid_key'])  
          population[parents[i]]['numerosity']=population[parents[i]]['numerosity']+1             
          return
    
    #check can action set subsume the offspring
    result=subsumeClassifierToSet(population,offspring,action_set,pool)
    # if any action set can subsume this offspring, then this offspring will be deleted
    if result:
        return
    
    #check do population include this classifier rule, if not add it into population
    addclassifierToSet(population,offspring,pool)


def getDiscoversSums(population,action_set):
    fitsum=0.0
    setsum=0
    gaitsum=0
    for i in action_set:
        fitsum=fitsum+population[i]['fitness']
        setsum=setsum+population[i]['numerosity']
        gaitsum=gaitsum+population[i]['timeStamp']*population[i]['numerosity']
    return fitsum, setsum, gaitsum

def insertDiscoveredClassifier(population,offspring,parents,action_set,pool,total_numerosity):
        
    if config.doGASubsumption:
        for off_num in range(0,len(offspring)):
            subsumeClassifier(population,offspring[off_num],parents,action_set,pool)

    else:
        for off_num in range(0,len(offspring)):
            addclassifierToSet(population,offspring[off_num],pool)

    
    total_numerosity=total_numerosity+len(offspring)
    offspring=[]
   # print total_numerosity
    empty=[]
    while total_numerosity>maxPopSize:
        deleteStochClassifier_match_set(population,pool,empty)
        total_numerosity=total_numerosity-1

########################## save the classifier rules ###########################
def sort_population(population):
    sort_dict=copy.deepcopy(population)
    result={}       
    for i in range(0, len(sort_dict)):
        max=-100
        max_ID=None
        for  per in sort_dict: 
                if sort_dict[per]['numerosity']>max:
                    max=sort_dict[per]['numerosity']
                    max_ID=per
        if max_ID!=None:
                result.setdefault(i,sort_dict[max_ID])
                del sort_dict[max_ID]
            #print max
    return result

def cover_classifier_to_string_2(input_dictionary):
    final_result=''
    result=''
    #print len(input_dictionary)
    for dic in input_dictionary:
            #print dic
            #print input_dictionary[dic]
            for i in input_dictionary[dic]['attribute']:
                result=result+str(i)+' '+'Upper: '+str(input_dictionary[dic]['condition'][i]['Upper'])+' '+'Lower: '+str(input_dictionary[dic]['condition'][i]['Lower'])+' | '
            result=result+' : '
            result=result+str(input_dictionary[dic]['action'])
            result=result+' '
            result=result+'----> Numerosity: '+str(input_dictionary[dic]['numerosity'])+' '
            
            input_dictionary[dic]['accuracy']=("%.2f" % input_dictionary[dic]['accuracy'])
            result=result+'Accuracy: '+str(input_dictionary[dic]['accuracy'])+' '
            
            input_dictionary[dic]['fitness']=("%.2f" % input_dictionary[dic]['fitness'])
            result=result+'Fitness: '+str(input_dictionary[dic]['fitness'])+' '
            
            input_dictionary[dic]['predictionError']=("%.2f" % input_dictionary[dic]['predictionError'])
            result=result+'Prediction Error: '+str(input_dictionary[dic]['predictionError'])+' '
            
            input_dictionary[dic]['prediction']=("%.2f" % input_dictionary[dic]['prediction'])
            result=result+'Prediction: '+str(input_dictionary[dic]['prediction'])+' '
            result=result+'Experience: '+str(input_dictionary[dic]['experience'])+' '

            input_dictionary[dic]['actionSetSize']=("%.2f" % input_dictionary[dic]['actionSetSize'])
            result=result+'ActionSetSize: '+str(input_dictionary[dic]['actionSetSize'])+'\n'
            final_result=final_result+ result
            result=''        
    return final_result

##########################     XCS implement part ####################################
def discoveryComponent(population,action_set,pool,itTime,state):
    fitsum=0.0#sum of fitness
    setsum=0#sum of numerosity
    gaitsum=0#sum of timeStamp*numerosity

    # if the classifier set is empty, return (due to deletion)
    if action_set==None or len(action_set)==0:
        return

    #get all sums that are needed to do the discovery
    fitsum,setsum,gaitsum=getDiscoversSums(population,action_set)

    #do not do a GA is the average number of time-steps in the set since the last GA is less or equal than thetaGA
    if itTime-float(gaitsum)/float(setsum) <config.theta_GA:
         return

    for i in action_set:
        population[i]['timeStamp']=itTime

    parents, offsprings=ALKR_selectTwoClassifiers(population,action_set,pool,state)

    total_numerosity=0
    for i in population:
        total_numerosity=total_numerosity+population[i]['numerosity']   

    insertDiscoveredClassifier(population,offsprings,parents,action_set,pool,total_numerosity)


def doOneSingleStepProblemExplore(population,state, counter,pool,action):
    #get the match set
    match_set=[]
    action_set=[]
    match_set=getMatchSet(population,state,counter,pool)
    #calculate the prediction array
    predictionArray,sumClfrFitnessInPredictionArray=getPredictionArray(population,match_set)
    #Got the action winner based on randomly
    actionwinner=randomActionWinner(sumClfrFitnessInPredictionArray)
    #get the action set
    action_set=getActionSet(population,actionwinner,match_set)
    #calculate the reward
    if action==actionwinner:
        reward=R_env.maxPayOff
    else:
        reward=0
    
    updateActionSet(population,0.0,reward,action_set,pool)
    #discovery new classifier based on mutation and crossover

    discoveryComponent(population,action_set,pool,counter,state)
    match_set=[]
    action_set=[]

def doOneSingleStepProblemExploit(population,state,counter,pool):
    #match_set=[]
    #match_set=getMatchSet(population,state,counter,pool)
    getMatchSet(population,state,counter,pool)

def doOneSingleStepExperiment(population,pool):
    explore=0
    for exploreProbC in range(0,maxproblemsize):
        explore=(explore+1)%2
        state=env.Create_Set_condition(problem_length)
        if explore==1:
            doOneSingleStepProblemExplore(population,state,exploreProbC,pool)
        else:
            doOneSingleStepProblemExploit(population,state,exploreProbC,pool)

def Test_exploit(population,pool):
    #self.Read_xcs(Address)
    number_of_correct=0
    total_number=1000

    for i in range(0,total_number):
        T_match_set=[]
        state, action=R_env.random_state_action()
        T_match_set=get_Test_MatchSet(population,state,pool)
        predictionArray,sumClfrFitnessInPredictionArray=getPredictionArray(population,T_match_set)
        actionWinner=bestActionWinner(predictionArray)

        if actionWinner==action:
            number_of_correct=number_of_correct+1

    print (100.0*number_of_correct/total_number ,'%')
    T_match_set=[]
    return str(100.0*number_of_correct/total_number)

def get_Test_MatchSet(population,state,pool):
    #print "begin"
    parameters=[]
    #calculate the population size
    for i in population:
        temp=[]
        temp.append(state)
        temp.append(population[i])     
        parameters.append(temp)

    Candidate_match_set=pool.map(ALKRisConditionMatched_P,parameters)
    T_match_set=[]
    #calculate size of the match set
    for i in Candidate_match_set:
        if i!=None:
            T_match_set.append(i)
    return T_match_set

def doOneSingleStepExperiment_with_Test(population,pool):
    explore=0
    for exploreProbC in range(0,maxproblemsize):
        explore=(explore+1)%2
        state, action =R_env.random_state_action()
        if explore==1:
            doOneSingleStepProblemExplore(population,state,exploreProbC,pool,action)
        else:
            doOneSingleStepProblemExploit(population,state,exploreProbC,pool)
        if exploreProbC %Test_record_step==0:
            Test_records.append(Test_exploit(population,pool))

def save_performance(txt,name):
    f=open(name,'wb')
    f.write(txt.encode())
    f.close()

def start_XCS(pool):
    hour_1,min_1,second_1=Header()
    population={}
    doOneSingleStepExperiment(population,pool)
    use_t=Exit(hour_1,min_1,second_1)
    Test_exploit(population,pool)
    sorted_population=sort_population(population)
    result=cover_classifier_to_string_2(sorted_population)
    name=''
    ID=str(uuid.uuid4())
    Time=config.startTimer()
    usetime=str(Time[0])
    r_time=''
    for us in usetime:
        if us=='-' or us==':'  or us==' ':
            r_time=r_time+'_'
        else:
            r_time=r_time+us
       
    id=''
    for st in ID:
        if st=='-':
            id=id+'_'
        else:
            id=id+str(st)
    name=name+OIS_config.XCS_Name+config.XCS_version+OIS_config.XCS_AgentName+id+ OIS_config.XCS_Problem_Name+OIS_config.Question_Types[problem_type]+OIS_config.XCS_Problem_Length_Name+str(problem_length)+OIS_config.XCS_Finish_Time_Name+r_time+'.txt'
    #save_performance(str(use_t))
    save_performance(result,name)

def start_XCS_with_test(pool):
    hour_1,min_1,second_1=Header()
    population={}
    doOneSingleStepExperiment_with_Test(population,pool)
    use_t=Exit(hour_1,min_1,second_1)
    Test_exploit(population,pool)
    sorted_population=sort_population(population)
    result=cover_classifier_to_string_2(sorted_population)
    name=''
    ID=str(uuid.uuid4())
    Time=config.startTimer()
    usetime=str(Time[0])
    r_time=''
    for us in usetime:
        if us=='-' or us==':'  or us==' ':
            r_time=r_time+'_'
        else:
            r_time=r_time+us
       
    id=''
    for st in ID:
        if st=='-':
            id=id+'_'
        else:
            id=id+str(st)
    name=name+'Agent'+id+ '_problems'+R_env.problem_types[R_problem_Type]+ '_Attribute'+str(R_env.attributes)+OIS_config.XCS_Finish_Time_Name+r_time+'_XCSXCSRC'+str(test_fold)+'.txt'


    Train_info=''
    for T_R in Test_records:
        Train_info = Train_info+T_R+' '

    TR_name='TR'
    TR_name=TR_name+'T'+'Agent'+id+ '_problems'+R_env.problem_types[R_problem_Type]+ '_Attribute'+str(R_env.attributes)+OIS_config.XCS_Finish_Time_Name+r_time+'_XCSXCSRC'+str(test_fold)+'.txt'

    if not Is_LinuX:
        Windiw_path='Result/'
        save_performance(result,Windiw_path+name)
        save_performance(Train_info,Windiw_path+TR_name)
    else:
        Linux_path=os.getcwd()+'/Parallel_XCS/Result/'
        save_performance(result,Linux_path+name)
        save_performance(Train_info,Linux_path+TR_name)
    
def print_population(population):
    for i in population:
        print (population[i])
    print (len(population))

if __name__=='__main__':
     cores=multiprocessing.cpu_count()
     pool= multiprocessing.Pool(processes=cores)
     #population={}
     #Unused_Hash=Initial_Hash()
     #used_Hash=[]
    
     for i in range(0,1):
         #state, action=R_env.random_state_action()
         #counter=0        
         #match_set=[]
         #action_set=[]
         #match_set=getMatchSet(population,state,counter,pool)
         #print population
         
         Test_records=[]
         Unused_Hash=Initial_Hash()
         used_Hash=[]
         #start_XCS(pool)
         start_XCS_with_test(pool)
         print ('===============================================')    
     pool.close()
